import { identifierModuleUrl } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-progress',
  templateUrl: './progress.component.html',
  styleUrls: ['./progress.component.css']
})


  export class ProgressComponent implements OnInit {

  stepTraversal: { stepNo: number, stepDescription: string , stepState: string}[] = [
      
      { "stepNo": 1, "stepDescription": "Reporting Information", "stepState" : "Active"},
      { "stepNo": 2, "stepDescription": "Insured Driver" , "stepState" : "Inactive"},
      { "stepNo": 3, "stepDescription": "Losses & Damage" , "stepState" : "Inactive"},
      { "stepNo": 4, "stepDescription": "Injuries & Witnesses" , "stepState" : "Inactive"},
      { "stepNo": 5, "stepDescription": "Review & submit" , "stepState" : "Inactive"},
     
  ];

previousBtn = document.getElementById('previousBtn');
nextBtn = document.getElementById('nextBtn');
finishBtn = document.getElementById('finishBtn');
content = document.getElementById('content');
bullets  =  [...document.querySelectorAll('.bullet')];
MAX_STEPS = 5;
currentStep = 1;
previousStep;
currentState ="Inactive";

  constructor() {}

nxtBtn(){

if(this.currentStep !=this.MAX_STEPS){

    this.currentState = this.stepTraversal[this.currentStep].stepState;
    if(this.currentState == "Inactive")
      {
        this.currentState = "Active"
        const target = document.getElementsByClassName('bullet')[this.currentStep].classList.add('completed');
        const text = document.getElementsByClassName('step-text')[this.currentStep].classList.add('active');
        const target1 = document.getElementsByClassName('bullet')[this.currentStep-1].classList.add('previous');
        const text1 = document.getElementsByClassName('step-text')[this.currentStep-1].classList.add('previous');
      
      }
      else if(this.currentState == "Active")
      {
        this.currentState = "Done"
      }


 }
this.currentStep++;


}
 

prevBtn(){
 
 

  let currentState = this.stepTraversal[this.currentStep-1].stepState;
  console.log(this.currentStep);
  console.log(currentState);


  if(this.currentStep ! = 1)
  {
    if(currentState == "Active")
    {
      currentState = "Active";
      const target = document.getElementsByClassName('completed')[this.currentStep-1].classList.remove("completed");
      const text = document.getElementsByClassName('step-text')[this.currentStep-1].classList.add('active');
    
    }
  }
  
}

  ngOnInit(): void {

  }
  }